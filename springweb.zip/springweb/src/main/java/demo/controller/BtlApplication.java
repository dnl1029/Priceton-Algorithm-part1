package demo.controller;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import demo.dto.BoardDto;
import demo.dto.UserDto;
import demo.dao.BoardMapper;
import demo.dao.UserMapper;

@SpringBootApplication(scanBasePackages = {"demo"})
public class BtlApplication {
 
    private UserMapper uMapper;
    private BoardMapper bMapper;
    
    public void userTest() 
    {
        UserDto user = new UserDto();
        user.setUserId("test");
        user.setUserPw("test");
        user.setUserName("테스트");
        user.setUserGender("남");
        user.setUserEmail("test@test.test");
        uMapper.insertUser(user);
        
        System.out.println(uMapper.selectOneUser("test"));
    }

    public void boardTest() {
        BoardDto board = new BoardDto();
        board.setPassword("1234");
        board.setTitle("haoun blog");
        bMapper.insertBoard(board);
        System.out.println(bMapper.selectOneBoard(1));
    }
    
    public static void main(String[] args) throws Exception {
    	SpringApplication.run(BtlApplication.class, args);
    }
    
}